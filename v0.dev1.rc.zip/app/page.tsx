'use client'

import { useState, useEffect } from 'react'
import { LanguageProvider, useLanguage } from '@/lib/language-context'
import { Header } from '@/components/header'
import { Navigation } from '@/components/navigation'
import { Dashboard } from '@/components/dashboard'
import { PunchCard } from '@/components/punch-card'
import { VehicleLogBook } from '@/components/vehicle-log'
import { ReceiptManagement } from '@/components/receipt-management'
import { AlertCircle, Shield } from 'lucide-react'

type TabType = 'dashboard' | 'punch' | 'vehicle' | 'receipts'

interface User {
  id: string
  name: string
  email: string
  avatarUrl?: string
}

function MainApp() {
  const { t, language } = useLanguage()
  const [user, setUser] = useState<User | null>(null)
  const [activeTab, setActiveTab] = useState<TabType>('dashboard')
  const [isLoading, setIsLoading] = useState(true)
  
  // Check for existing session
  useEffect(() => {
    const savedUser = localStorage.getItem('demo_user')
    if (savedUser) {
      setUser(JSON.parse(savedUser))
    }
    setIsLoading(false)
  }, [])
  
  // Demo login (replace with Supabase Google Auth when connected)
  const handleLogin = () => {
    // For demo purposes - simulate Google login
    const demoUser: User = {
      id: 'demo-user-001',
      name: 'Ahmad bin Abdullah',
      email: 'ahmad@jabatan.gov.my',
    }
    setUser(demoUser)
    localStorage.setItem('demo_user', JSON.stringify(demoUser))
  }
  
  const handleLogout = () => {
    setUser(null)
    localStorage.removeItem('demo_user')
    setActiveTab('dashboard')
  }
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    )
  }
  
  return (
    <div 
      className="min-h-screen anime-bg"
      style={{ backgroundImage: 'url(/anime-bg.jpg)' }}
    >
      <div className="min-h-screen gradient-overlay">
        <Header 
          user={user} 
          onLogin={handleLogin} 
          onLogout={handleLogout} 
        />
        
        {user ? (
          <>
            <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
            
            <main className="max-w-7xl mx-auto px-4 py-6">
              {/* Supabase Connection Notice */}
              <div className="mb-6 p-4 rounded-xl bg-amber-100 dark:bg-amber-900/30 border border-amber-200 dark:border-amber-800">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-amber-800 dark:text-amber-200">
                      {t.connectSupabase}
                    </p>
                    <p className="text-xs text-amber-700 dark:text-amber-300 mt-1">
                      {language === 'ms' 
                        ? 'Data disimpan dalam localStorage untuk tujuan demo. Sambungkan Supabase untuk penyimpanan data kekal dan pengesahan Google.'
                        : 'Data is stored in localStorage for demo purposes. Connect Supabase for persistent storage and Google authentication.'}
                    </p>
                  </div>
                </div>
              </div>
              
              {activeTab === 'dashboard' && <Dashboard userId={user.id} />}
              {activeTab === 'punch' && <PunchCard userId={user.id} />}
              {activeTab === 'vehicle' && <VehicleLogBook userId={user.id} />}
              {activeTab === 'receipts' && <ReceiptManagement userId={user.id} />}
            </main>
          </>
        ) : (
          <main className="max-w-4xl mx-auto px-4 py-12">
            <div className="glass-card rounded-2xl p-8 text-center">
              <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-primary/10 flex items-center justify-center">
                <Shield className="w-10 h-10 text-primary" />
              </div>
              
              <h1 className="text-3xl font-bold text-foreground mb-4">
                {t.systemTitle}
              </h1>
              
              <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
                {language === 'ms' 
                  ? 'Sistem pengurusan kehadiran kakitangan, log kenderaan kerajaan, dan pengurusan resit. Sila log masuk untuk meneruskan.'
                  : 'Staff attendance management system, government vehicle logs, and receipt management. Please login to continue.'}
              </p>
              
              <button
                onClick={handleLogin}
                className="btn-3d inline-flex items-center gap-3 px-8 py-4 rounded-xl bg-primary text-primary-foreground text-lg font-semibold"
              >
                <svg className="w-6 h-6" viewBox="0 0 24 24">
                  <path
                    fill="currentColor"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="currentColor"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="currentColor"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                  />
                  <path
                    fill="currentColor"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  />
                </svg>
                {t.login}
              </button>
              
              {/* Features Preview */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
                <div className="p-6 bg-secondary/50 rounded-xl">
                  <div className="w-12 h-12 mx-auto mb-4 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                    <svg className="w-6 h-6 text-blue-600 dark:text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">
                    {t.punchCard}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {language === 'ms' 
                      ? 'Rakam kehadiran WFH dengan pengiraan OT automatik'
                      : 'Record WFH attendance with automatic OT calculation'}
                  </p>
                </div>
                
                <div className="p-6 bg-secondary/50 rounded-xl">
                  <div className="w-12 h-12 mx-auto mb-4 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                    <svg className="w-6 h-6 text-green-600 dark:text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10a1 1 0 001 1h1m8-1a1 1 0 01-1 1H9m4-1V8a1 1 0 011-1h2.586a1 1 0 01.707.293l3.414 3.414a1 1 0 01.293.707V16a1 1 0 01-1 1h-1m-6-1a1 1 0 001 1h1M5 17a2 2 0 104 0m-4 0a2 2 0 114 0m6 0a2 2 0 104 0m-4 0a2 2 0 114 0" />
                    </svg>
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">
                    {t.vehicleLog}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {language === 'ms' 
                      ? 'Buku log kenderaan kerajaan dengan kiraan automatik'
                      : 'Government vehicle log book with automatic calculations'}
                  </p>
                </div>
                
                <div className="p-6 bg-secondary/50 rounded-xl">
                  <div className="w-12 h-12 mx-auto mb-4 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                    <svg className="w-6 h-6 text-purple-600 dark:text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">
                    {t.receipts}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {language === 'ms' 
                      ? 'Muat naik dan urus resit minyak, TNG, tol'
                      : 'Upload and manage fuel, TNG, toll receipts'}
                  </p>
                </div>
              </div>
            </div>
          </main>
        )}
        
        {/* Footer */}
        <footer className="mt-auto py-4 text-center text-sm text-muted-foreground">
          <p>
            {language === 'ms' 
              ? '© 2026 Jabatan Penguatkuasaan. Hak Cipta Terpelihara.'
              : '© 2026 Enforcement Department. All Rights Reserved.'}
          </p>
        </footer>
      </div>
    </div>
  )
}

export default function HomePage() {
  return (
    <LanguageProvider>
      <MainApp />
    </LanguageProvider>
  )
}
